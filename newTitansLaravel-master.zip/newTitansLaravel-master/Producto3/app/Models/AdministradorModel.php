<?php

namespace App\Models;

use Illuminate\Foundation\Auth\User as Authenticatable;

class AdministradorModel extends Authenticatable
{
    protected $table = 'transfer_administradores';
    protected $fillable = ['nombre','apellido1','email','password','isAdmin'];
    protected $guard = 'administrador';
    public $timestamps = false;
}
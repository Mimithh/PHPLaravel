<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;

class UsuarioModel extends Authenticatable
{
    use HasFactory;

    protected $table = 'transfer_viajeros';
    protected $guard = 'viajero';
    protected $fillable = ['nombre', 'apellido1', 'apellido2', 'direccion', 'codigoPostal', 'ciudad', 'pais', 'email', 'password', 'isAdmin'];
    public $timestamps = false;
}

<?php

namespace App\Models;
use App\Models\Hotel;
use App\Models\Aeropuerto;
use App\Models\Zona;
use App\Models\Vehiculo;
use Illuminate\Database\Eloquent\Model;

class Reserva extends Model
{
    
    protected $table = 'transfer_reservas';
    protected $primaryKey = 'id_reserva';

    
    public $timestamps = true;

    const CREATED_AT = 'fecha_reserva';
    const UPDATED_AT = 'fecha_modificacion';

    
    protected $fillable = [
        'localizador',
        'id_hotel', 
        'id_tipo_reserva',
        'email_cliente',
        'fecha_entrada',
        'hora_entrada',
        'numero_vuelo_entrada',
        'origen_vuelo_entrada',
        'hora_vuelo_salida',
        'fecha_vuelo_salida',
        'num_viajeros',
        'id_vehiculo',
        'numero_vuelo_salida',
        'hora_recogida',
        'id_destino',

    ];

   
        public function hotel()
    {
        return $this->belongsTo(Hotel::class, 'id_hotel', 'id_hotel');
    }   

    public function destino()
    {
        return $this->belongsTo(Aeropuerto::class, 'id_destino', 'id_destino');
    }

    public function zona()
    {
        return $this->belongsTo(Zona::class, 'id_zona', 'id_zona');
    }

    public function vehiculo()
{
    
    return $this->belongsTo(Vehiculo::class, 'id_vehiculo', 'id_vehiculo');
}
}
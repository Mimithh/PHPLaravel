<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash; 


class loginModel extends Model
{
    public function loginUnificado($usuario, $password){
    if (str_contains($usuario, ' ')) {
        [$nombre, $apellido] = explode(' ', $usuario, 2);
    } else {
        $nombre = $usuario;
        $apellido = '';
    }

    $query = "SELECT email, nombre, apellido1, password, isAdmin FROM transfer_viajeros
        WHERE email = ? OR (nombre = ? AND apellido1 = ?)
        UNION
        SELECT email, nombre, apellido1, password, isAdmin FROM transfer_administradores
        WHERE email = ? OR (nombre = ? AND apellido1 = ?)
        UNION
        SELECT email, nombre_empresa AS nombre, '' AS apellido1, password, isAdmin FROM transfer_corporativos
        WHERE email = ? OR nombre_empresa = ?";

    $params = [
        $usuario, $nombre, $apellido,  // transfer_viajeros
        $usuario, $nombre, $apellido,  // transfer_administradores
        $usuario, $usuario              // transfer_corporativos
    ];

    $user = DB::selectOne($query, $params);
    if ($user && Hash::check($password, $user->password)) {
        return ['success' => true, 'user' => (array)$user];
    } else {
        return ['success' => false, 'message' => 'Credenciales Incorrectas'];
    }

    }
}


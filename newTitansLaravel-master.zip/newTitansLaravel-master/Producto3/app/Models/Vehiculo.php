<?php
// app/Models/Vehiculo.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Vehiculo extends Model
{
    protected $table      = 'transfer_vehiculo';
    protected $primaryKey = 'id_vehiculo';
    public $timestamps    = false;

    protected $fillable = [
        'Descripción',
        'email_conductor',
        'password',
    ];
}
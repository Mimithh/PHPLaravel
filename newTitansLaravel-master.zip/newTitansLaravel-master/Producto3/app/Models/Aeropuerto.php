<?php
// app/Models/Aeropuerto.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Aeropuerto extends Model
{
    protected $table      = 'transfer_aero';
    protected $primaryKey = 'id_destino';
    public $timestamps    = false;

    protected $fillable = [
        'aeropuerto',
    ];
}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\AdministradorModel;
use App\Models\CorporativoModel;
use App\Models\UsuarioModel;
use Hash;
use DB;

class RegistroController extends Controller
{
    public function showForm(){
        $adminLogIn = session('isAdmin') == 1;
        $totalAdmins = \App\Models\AdministradorModel::count();

        
            return view('registro', compact('adminLogIn','totalAdmins'));
    }

    public function register(Request $request){
        $validatedData=$request -> validate([
            'nombre'=> 'required_if: isAdmin,0,1',
            'nombre_empresa'=> 'required_if:isAdmin,2',
            'apellido1'=> 'required_if:isAdmin,0,1',
            'apellido2'=> 'required_if:isAdmin,0',
            'email' => 'required|email|unique:transfer_viajeros,email|unique:transfer_administradores,email|unique:transfer_corporativos,email',
            'password'=>'required',
            'direccion'=> 'required_if:isAdmin,0',
            'codigoPostal'=> 'required_if:isAdmin,0',
            'ciudad'=> 'required_if:isAdmin,0',
            'pais'=> "required_if:isAdmin,0",
            'isAdmin'=>'required',
            
        ]);
        
        $password = Hash::make($validatedData['password']);
        $isAdmin = $validatedData['isAdmin'];
        $tablaUser = $this->tableUsers($isAdmin);

        // Segun el tipo de usuario, se guarda en la tabla correspondiente
        if ($isAdmin == 1) { // Si es Administrador isAdmin = 1
            AdministradorModel::create([
                'nombre' => $validatedData['nombre'],
                'apellido1' => $validatedData['apellido1'],
                'email' => $validatedData['email'],
                'password' => $password,
                'isAdmin' => 1,
            ]);
        } elseif ($isAdmin == 2) { // Si es Corporativo isAdmin = 2
            CorporativoModel::create([
                'nombre_empresa' => $validatedData['nombre_empresa'],
                'email' => $validatedData['email'],
                'password' => $password,
                'isAdmin' => 2,
            ]);
        } else { // Si es usuario "normal" isAdmin = 0
            UsuarioModel::create([
                'nombre' => $validatedData['nombre'],
                'apellido1' => $validatedData['apellido1'],
                'apellido2' => $validatedData['apellido2'],
                'email' => $validatedData['email'],
                'password' => $password,
                'direccion' => $validatedData['direccion'],
                'codigoPostal' => $validatedData['codigoPostal'],
                'ciudad' => $validatedData['ciudad'],
                'pais' => $validatedData['pais'],
                'isAdmin' => 0,
            ]);
        }
        
        if (isset($validatedData['nombre'], $validatedData['isAdmin']) && $validatedData['isAdmin'] == 1) {
            session(['nombre' => $validatedData['nombre']]);
            session(['isAdmin' => $isAdmin]);
        } elseif (isset($validatedData['nombre_empresa']) && $isAdmin == 2) {
            session(['nombre' => $validatedData['nombre_empresa']]);
            session(['isAdmin' => $isAdmin]);
        } else {
            session(['nombre' => $validatedData['nombre'] ?? $validatedData['nombre_empresa'] ?? '']);
            session(['isAdmin' => $isAdmin]);
        }
        
        // Guardar nuevo usuario en su tabla correspondiente    
        return redirect()->route('index');
    }

    private function tableUsers($isAdmin){
        if ($isAdmin == "1") {
            return 'transfer_administradores';
        } elseif ($isAdmin == "2") {
            return 'transfer_corporativos';
        } else {
            return 'transfer_viajeros';  
        }
    }

    public function success(Request $request){
        $nombre = $request->query('nombre');
        $isAdmin = $request->query('isAdmin');

        return view('index', compact('nombre', 'isAdmin'));
    }
}

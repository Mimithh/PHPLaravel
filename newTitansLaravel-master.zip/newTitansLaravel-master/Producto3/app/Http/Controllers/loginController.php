<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class loginController extends Controller
{
    public function showLoginForm(Request $request){
        return view('login', [
            'registro' => $request->query('registro'),
            'nombre' => $request->query('nombre'),
            'isAdmin' => $request->query('isAdmin'),
            'error' => $request->query('error'),
        ]);
    }

    public function login(Request $request){
        $usuario = $request->input('user');
        $password = $request->input('password');

        $userUnique = app(\App\Models\loginModel::class)->loginUnificado($usuario, $password);

        if ($userUnique['success']) {
            session([
                'userName' => $userUnique['user']['nombre'],
                'isAdmin' => $userUnique['user']['isAdmin'],
            ]);
           
            
            

            if ($userUnique['user']['isAdmin'] == 1) {
                return redirect()->route('perfilAdmin');
            } elseif ($userUnique['user']['isAdmin'] == 0) {
                return redirect('/userprofile');
            } elseif ($userUnique['user']['isAdmin'] == 2) {
                return redirect()->route('perfilCorp');
            }
        }else{
                return redirect()->route('login.form')->with('error', 'Tipo de usuario no reconocido');
            }
            
        }
}

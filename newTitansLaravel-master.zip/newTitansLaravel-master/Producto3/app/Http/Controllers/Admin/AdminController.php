<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Zona;              
use App\Models\Vehiculo;    
use App\Models\Aeropuerto;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:administrador');
    }

    public function index()
    {
        $trayectos = [
            [
                'tipo' => 'aeropuerto-hotel',
                'img'  => 'aero-hotel.png',
                'alt'  => 'Aeropuerto → Hotel',
                'id'   => 'aeroHotel',          
            ],
            [
                'tipo' => 'hotel-aeropuerto',
                'img'  => 'hotel-aero.jpg',
                'alt'  => 'Hotel → Aeropuerto',
                'id'   => 'hotelAero',
            ],
            [
                'tipo' => 'ida-vuelta',
                'img'  => 'idavuelta.jpg',
                'alt'  => 'Ida y Vuelta',
                'id'   => 'idaVuelta',
            ],
        ];
        $zonas       = Zona::with('hoteles')->get();     
        $vehiculos   = Vehiculo::all();
        $aeropuertos = Aeropuerto::all();

        return view('admin.perfilAdmin', compact(
            'trayectos','zonas','vehiculos','aeropuertos'
        ));
    }
    
}
<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\Models\Reserva;
use App\Models\Vehiculo;

class ReservasController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth:administrador');
    }

    /**
     * Comprueba si un email ya existe en administradores, corporativos o viajeros.
     * Devuelve JSON ['exists' => true|false].
     */
    public function checkEmail(Request $request)
    {
        $email = $request->query('email');

        $exists = DB::table('transfer_administradores')
                    ->where('email', $email)
                    ->exists()
               || DB::table('transfer_corporativos')
                    ->where('email', $email)
                    ->exists()
               || DB::table('transfer_viajeros')
                    ->where('email', $email)
                    ->exists();

        return response()->json(['exists' => $exists]);
    }

    /**
     * Valida datos, crea un nuevo viajero si el email no existía, 
     * genera localizador, asigna vehículo y guarda la reserva.
     */
    public function store(Request $request)
    {
        // 1) Validar datos básicos según el tipo de reserva
        $data = $request->validate([
            'id_tipo_reserva'        => 'required|integer|in:1,2,3',
            'num_viajeros'           => 'required|integer|min:1|max:8',
            'email_cliente'          => 'required|email',

            // Tipo 1: Aeropuerto → Hotel
            'fecha_entrada'          => 'required_if:id_tipo_reserva,1|date',
            'hora_entrada'           => 'required_if:id_tipo_reserva,1',
            'numero_vuelo_entrada'   => 'required_if:id_tipo_reserva,1|string|max:50',
            'origen_vuelo_entrada'   => 'required_if:id_tipo_reserva,1|exists:transfer_aero,id_destino',

            // Tipo 2: Hotel → Aeropuerto
            'fecha_vuelo_salida'     => 'required_if:id_tipo_reserva,2|date',
            'hora_vuelo_salida'      => 'required_if:id_tipo_reserva,2',
            'numero_vuelo_salida'    => 'required_if:id_tipo_reserva,2|string|max:50',
            'hora_recogida'          => 'required_if:id_tipo_reserva,2',

            // Tipo 3: Ida y Vuelta
            'fecha_entrada'          => 'required_if:id_tipo_reserva,3|date',
            'hora_entrada'           => 'required_if:id_tipo_reserva,3',
            'numero_vuelo_entrada'   => 'required_if:id_tipo_reserva,3|string|max:50',
            'origen_vuelo_entrada'   => 'required_if:id_tipo_reserva,3|exists:transfer_aero,id_destino',

            'fecha_vuelo_salida'     => 'required_if:id_tipo_reserva,3|date',
            'hora_vuelo_salida'      => 'required_if:id_tipo_reserva,3',
            'numero_vuelo_salida'    => 'required_if:id_tipo_reserva,3|string|max:50',
            'hora_recogida'          => 'required_if:id_tipo_reserva,3',

            // Campos comunes
            'id_hotel'               => 'required_if:id_tipo_reserva,1,2,3|exists:transfer_hotel,id_hotel',
            'id_destino'             => 'required_if:id_tipo_reserva,2,3|exists:transfer_aero,id_destino',
            'id_zona'                => 'required_if:id_tipo_reserva,2,3|exists:transfer_zona,id_zona',
        ]);

        // 2) Comprobar en servidor si el email ya existe
        $email = $data['email_cliente'];
        $exists = DB::table('transfer_administradores')->where('email', $email)->exists()
               || DB::table('transfer_corporativos')->where('email', $email)->exists()
               || DB::table('transfer_viajeros')->where('email', $email)->exists();

        // 3) Si NO existe, validar e insertar el nuevo viajero
        if (! $exists) {
            $extra = $request->validate([
                'nombre'        => 'required|string|max:100',
                'apellido1'     => 'required|string|max:100',
                'apellido2'     => 'nullable|string|max:100',
                'direccion'     => 'required|string|max:255',
                'codigoPostal'  => 'required|numeric',
                'ciudad'        => 'required|string|max:100',
                'pais'          => 'required|string|max:100',
                'password'      => 'required|string',
            ]);

            DB::table('transfer_viajeros')->insert([
                'email'   => $email,
                'nombre'          => $extra['nombre'],
                'apellido1'       => $extra['apellido1'],
                'apellido2'       => $extra['apellido2'],
                'direccion'       => $extra['direccion'],
                'codigoPostal'   => $extra['codigoPostal'],
                'ciudad'          => $extra['ciudad'],
                'pais'            => $extra['pais'],
                'password'        => Hash::make($extra['password']),
                'isAdmin'      => 0,  
            ]);
        }

        // 4) Generar un localizador único
        do {
            $code = strtoupper(Str::random(8));
        } while (Reserva::where('localizador', $code)->exists());
        $data['localizador'] = $code;

        // 5) Asignar un vehículo al azar
        $vehiculo = Vehiculo::inRandomOrder()->first();
        if (! $vehiculo) {
            return back()
                   ->withErrors(['id_vehiculo' => 'No hay vehículos disponibles.'])
                   ->withInput();
        }
        $data['id_vehiculo'] = $vehiculo->id_vehiculo;

        // 6) Crear la reserva (Eloquent rellenará los timestamps)
        $reserva = Reserva::create($data);

        // 7) Redirigir con mensaje de éxito
        return redirect()
               ->route('admin.profile')
               ->with('status', "✅ Reserva creada correctamente. Localizador: {$reserva->localizador}");
    }

    
    public function events()
    {
        // Trae todas (o filtra a futuro si prefieres)
        $reservas = Reserva::all();

        $events = $reservas->map(function($r) {
            // Monta la fecha y hora de inicio
            // Ajusta nombres de campos si los tuyos son distintos
            if ($r->id_tipo_reserva == 1) {
                $start = "{$r->fecha_entrada}T{$r->hora_entrada}";
                $end   = null;
            } elseif ($r->id_tipo_reserva == 2) {
                $start = "{$r->fecha_vuelo_salida}T{$r->hora_recogida}";
                $end   = null;
            } else {
                $start = "{$r->fecha_entrada}T{$r->hora_entrada}";
                $end   = "{$r->fecha_vuelo_salida}T{$r->hora_recogida}";
            }

            return [
                'id'    => $r->id_reserva,
                'title' => $r->localizador,
                'start' => $start,
                'end'   => $end,
            ];
        });

        return response()->json($events);
    }

    public function show(Reserva $reserva)
{
    $reserva->load('hotel','destino','zona','vehiculo');

    $attrs  = $reserva->getAttributes();
    $filled = array_filter($attrs, fn($v) => !is_null($v) && $v !== '');

    $fields = [];
    foreach ($filled as $key => $value) {
        switch ($key) {
            case 'id_hotel':
                // aquí sacamos el nombre del hotel
                $fields['Hotel'] = optional($reserva->hotel)->nombre_hotel
                                   ?? "ID {$value}";
                break;

            case 'id_destino':
                $fields['Aeropuerto destino'] = optional($reserva->destino)->aeropuerto
                                               ?? "ID {$value}";
                break;

            case 'id_zona':
                $fields['Zona'] = optional($reserva->zona)->descripcion
                                ?? "ID {$value}";
                break;

            case 'id_vehiculo':
                
                $fields['Vehículo'] = optional($reserva->vehiculo)->Descripción
                                      ?? "ID {$value}";
                break;

            case 'id_tipo_reserva':
                $mapping = [
                  1 => 'Aeropuerto → Hotel',
                  2 => 'Hotel → Aeropuerto',
                  3 => 'Ida y Vuelta',
                ];
                $fields['Tipo de reserva'] = $mapping[$value] ?? $value;
                break;

            default:
                $label = Str::title(str_replace('_', ' ', $key));
                $fields[$label] = $value;
        }
    }

    return view('admin.showReserva', compact('reserva','fields'));
}


public function destroy(Reserva $reserva)
{
    $reserva->delete();

    return redirect()
           ->route('admin.calendar')
           ->with('status', '✅ Reserva eliminada correctamente.');
}

}

<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\UsuarioModel;
use App\Models\CorporativoModel;
use App\Models\AdministradoModel;


class MultiAuthController extends Controller
{
    /**
     * Muestra el formulario de login.
     */
    public function showLoginForm()
    {
        return view('login');  
    }

    /**
     * Procesa el login multi-guard.
     */
    public function login(Request $request)
    {
        $data = $request->validate([
            'email'    => 'required|email',
            'password' => 'required|string',
        ]);
        $guards = ['administrador','corporativo','viajero'];

        foreach ($guards as $guard){
            if (Auth::guard($guard)->attempt($data,$request->boolean('remember'))) {
                // Saber que usuario es
               $user = Auth::guard($guard)->user();
                // Guardar  la sesion y el rol
                session([
                    'userName' => $user['nombre'] ?? $user['nombre_empresa'] ?? $user['email'],
                    'isAdmin'  => $guard === 'administrador' ? 1 : ($guard === 'corporativo' ? 2 : 0),
                ]);

                 // **Opción A**: si es administrador, vamos a tu ruta /adminprofile
            if ($guard === 'administrador') {
                return redirect()->route('admin.profile');
            }elseif($guard === 'corporativo'){
                return redirect()->route('index');// usar corp.profile
            }else{
                return redirect()->route('index');// usar user.profile

            };
        } 
            
        }

        return back()
            ->withErrors(['email' => 'Credenciales inválidas.'])
            ->withInput(['email' => $data['email'], 'type' => $guard]);
    }

    /**
     * Cierra sesión en cualquier guard activo.
     */
    public function logout(Request $request)
    {
        foreach (['viajero','corporativo','administrador'] as $guard) {
            if (Auth::guard($guard)->check()) {
                Auth::guard($guard)->logout();
            }
        }

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
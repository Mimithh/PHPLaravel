<?php

namespace App\Http\Controllers;

use App\Models\AdministradorModel;

class InicioController extends Controller{
    public function index() {
        $totalAdmins = AdministradorModel::where('isAdmin', 1)->count(); 
        
        if ($totalAdmins === 0) {
            return redirect()->route('registro');
        }

        return view('index');
    }

    public function registro(){
        $totalAdmins = AdministradorModel::where('isAdmin', 1)->count(); 
        return view('registro', [
            'adminLogIn' => false,
            'totalAdmins' => $totalAdmins
        ]);
    }
}

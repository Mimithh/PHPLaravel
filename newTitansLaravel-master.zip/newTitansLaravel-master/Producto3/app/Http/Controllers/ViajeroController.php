
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ViajeroController extends Controller
{
    
    public function checkEmail(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
        ]);

        $exists = DB::table('transfer_viajeros')
                    ->where('email', $request->email)
                    ->exists();

        return response()->json(['exists' => $exists]);
    }
}

document.addEventListener('DOMContentLoaded', () => {
    console.log("🌐 appZonas:", window.appZonas);
  
    if (!Array.isArray(window.appZonas)) return;
  
    document.querySelectorAll('.pa-zona-select').forEach(zonaSelect => {
      zonaSelect.addEventListener('change', () => {
        const formContainer = zonaSelect.closest('.pa-form-container');
        const hotelSelect   = formContainer.querySelector('.pa-hotel-select');
  
        hotelSelect.innerHTML = '<option disabled selected>Primero selecciona zona</option>';
  
        const zonaId = zonaSelect.value;
        const zona   = window.appZonas.find(z => String(z.id_zona) === zonaId);
        console.log("🏷 Zona seleccionada:", zona);
  
        if (!zona || !Array.isArray(zona.hoteles)) return;
  
        zona.hoteles.forEach(h => {
          const opt = document.createElement('option');
          opt.value       = h.id_hotel;
          opt.textContent = h.nombre_hotel;
          hotelSelect.append(opt);
        });
      });
    });
  });
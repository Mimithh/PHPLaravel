// public/js/tipoFormularios.js

document.addEventListener('DOMContentLoaded', () => {
  // ─── Selector de trayectos ───────────────────────────────────────────
  const opciones     = document.querySelectorAll('.pa-trayecto-opcion');
  const selector     = document.getElementById('options');
  const containerAH  = document.getElementById('form-aeropuerto-hotel');
  const containerHA  = document.getElementById('form-hotel-aeropuerto');
  const containerIV  = document.getElementById('form-ida-vuelta');
  const titulo       = document.getElementById('titulo-trayecto');

  // ─── Aeropuerto → Hotel ─────────────────────────────────────────────
  if (containerAH) {
    const formAH         = containerAH.querySelector('form');
    const emailInputAH   = formAH.querySelector('input[name="email_cliente"]');
    const extraFieldsAH  = formAH.querySelector('.datos-viajero-adicionales');
    const extraInputsAH  = extraFieldsAH.querySelectorAll('input');
    const checkUrlAH     = containerAH.dataset.checkEmailUrl;

    formAH.addEventListener('submit', async function(e) {
      e.preventDefault();
      const email = emailInputAH.value.trim();
      if (!email) return;

      if (extraFieldsAH.style.display === 'block') {
        formAH.submit();
        return;
      }

      try {
        const res  = await fetch(`${checkUrlAH}?email=${encodeURIComponent(email)}`);
        const json = await res.json();

        if (json.exists) {
          formAH.submit();
        } else {
          extraFieldsAH.style.display = 'block';
          extraInputsAH.forEach(i => i.required = true);
          extraInputsAH[0].focus();

          alert('El correo no está registrado. Por favor, rellena los datos del nuevo viajero.');
        }
      } catch (err) {
        console.error('Error comprobando email (AH):', err);
        formAH.submit();
      }
    });
  }

  // ─── Hotel → Aeropuerto ─────────────────────────────────────────────
  if (containerHA) {
    const formHA         = containerHA.querySelector('form');
    const emailInputHA   = formHA.querySelector('input[name="email_cliente"]');
    const extraFieldsHA  = formHA.querySelector('.datos-viajero-adicionales');
    const extraInputsHA  = extraFieldsHA.querySelectorAll('input');
    const checkUrlHA     = containerHA.dataset.checkEmailUrl;

    formHA.addEventListener('submit', async function(e) {
      e.preventDefault();
      const email = emailInputHA.value.trim();
      if (!email) return;

      if (extraFieldsHA.style.display === 'block') {
        formHA.submit();
        return;
      }

      try {
        const res  = await fetch(`${checkUrlHA}?email=${encodeURIComponent(email)}`);
        const json = await res.json();

        if (json.exists) {
          formHA.submit();
        } else {
          extraFieldsHA.style.display = 'block';
          extraInputsHA.forEach(i => i.required = true);
          extraInputsHA[0].focus();
          alert('El correo no está registrado. Por favor, rellena los datos del nuevo viajero.');
        }
      } catch (err) {
        console.error('Error comprobando email (HA):', err);
        formHA.submit();
      }
    });
  }

  // ─── Ida y Vuelta ────────────────────────────────────────────────────
  if (containerIV) {
    const formIV         = containerIV.querySelector('form');
    const emailInputIV   = formIV.querySelector('input[name="email_cliente"]');
    const extraFieldsIV  = formIV.querySelector('.datos-viajero-adicionales');
    const extraInputsIV  = extraFieldsIV.querySelectorAll('input');
    const checkUrlIV     = containerIV.dataset.checkEmailUrl;

    formIV.addEventListener('submit', async function(e) {
      e.preventDefault();
      const email = emailInputIV.value.trim();
      if (!email) return;

      if (extraFieldsIV.style.display === 'block') {
        formIV.submit();
        return;
      }

      try {
        const res  = await fetch(`${checkUrlIV}?email=${encodeURIComponent(email)}`);
        const json = await res.json();

        if (json.exists) {
          formIV.submit();
        } else {
          extraFieldsIV.style.display = 'block';
          extraInputsIV.forEach(i => i.required = true);
          extraInputsIV[0].focus();
          alert('El correo no está registrado. Por favor, rellena los datos del nuevo viajero.');
        }
      } catch (err) {
        console.error('Error comprobando email (IV):', err);
        formIV.submit();
      }
    });
  }

  // ─── Mostrar/ocultar formularios por tipo de trayecto ───────────────
  const mapping = {
    'aeropuerto-hotel':  containerAH,
    'hotel-aeropuerto':  containerHA,
    'ida-vuelta':        containerIV
  };

  function hideAllForms() {
    Object.values(mapping).forEach(f => f && (f.style.display = 'none'));
  }

  opciones.forEach(op => {
    op.addEventListener('click', () => {
      const tipo = op.dataset.tipo;
      if (selector) selector.style.display = 'none';
      hideAllForms();
      const cont = mapping[tipo];
      if (cont) {
        cont.style.display = 'block';
        if (titulo) titulo.textContent = op.querySelector('img').alt;
      }
    });
  });

  // ─── Botones “Volver a selección” ───────────────────────────────────
  document.querySelectorAll('.pa-btn-cambiar-trayecto').forEach(btn => {
    btn.addEventListener('click', e => {
      e.preventDefault();
      hideAllForms();
      if (selector) selector.style.display = 'block';
      if (titulo) titulo.textContent = '';
    });
  });
});

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InicioController;
use App\Http\Controllers\RegistroController;
use App\Http\Controllers\Auth\MultiAuthController;
use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\ReservasController;



// 1. Bienvenida de Laravel
Route::get('/laravel', fn() => view('welcome'));

// 2. Página de inicio
Route::get('/', [InicioController::class, 'index'])->name('index');

// 3. Registro
Route::get('/registro',          [RegistroController::class, 'showForm'])->name('registro');
Route::post('/registro',         [RegistroController::class, 'register'])->name('registro.register');
Route::get('/registro/success',  [RegistroController::class, 'success'])->name('registro.success');

// 4. Autenticación multi‐guard
Route::get('/login',   [MultiAuthController::class, 'showLoginForm'])->name('login');
Route::post('/login',  [MultiAuthController::class, 'login'])->name('login.post');
Route::post('/logout', [MultiAuthController::class, 'logout'])->name('logout');

// 5. Panel Administrador

Route::prefix('admin')
     ->name('admin.')
     ->middleware('auth:administrador')
     ->group(function() {
         // Mostrar el panel de administrador
         Route::get('profile', [AdminController::class, 'index'])
              ->name('profile');

         // Guardar una nueva reserva desde el panel
         Route::post('reservas', [ReservasController::class, 'store'])
              ->name('reservas.store');
     });
     // Página del calendario
Route::get('admin/calendar', function(){
     return view('admin.calendar');
 })->middleware('auth:administrador')->name('admin.calendar');
 
 // API JSON para eventos
 Route::get('admin/reservas/events', [\App\Http\Controllers\Admin\ReservasController::class, 'events'])
      ->middleware('auth:administrador')
      ->name('admin.reservas.events');

Route::get('admin/reservas/{reserva}', [\App\Http\Controllers\Admin\ReservasController::class, 'show'])
     ->name('admin.reservas.show');

     
Route::group(['middleware' => ['auth:administrador']], function() {
          Route::get('/admin/profile', [AdminController::class, 'index'])->name('admin.profile');
      });
    
Route::delete('admin/reservas/{reserva}', [ReservasController::class, 'destroy'])
     ->name('admin.reservas.destroy');

Route::get('admin/reservas/check-email', [ReservasController::class, 'checkEmail'])
           ->name('admin.reservas.checkEmail');
      
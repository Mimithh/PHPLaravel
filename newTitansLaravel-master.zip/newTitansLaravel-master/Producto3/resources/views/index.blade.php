<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Isla Transfers</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('css/style.css') }}?v={{ time() }}">
</head>
<body>

   
    @include('header')
    <section class="hero" id="inicio">
        <div class="hero-content">
            <h1 style="color: #FFFFFF;">Bienvenido a Nuestra Empresa</h1>
            <p style="color: #FFFFFF;">Ofrecemos servicios de transporte confiables y seguros.</p>
        </div>
    </section>

    <section class="services" id="servicios">
        <h2>NUESTROS SERVICIOS</h2>

        <div class="service">
            <img src="{{ asset('assets/imagenes/van.jpeg') }}" alt="Transporte Aeropuerto" class="service-img">
            <h3>Traslados Aeropuerto-Hotel y Hotel-Aeropuerto</h3>
            <p>Pulsa para más información</p>
        </div>

        <div class="service">
            <img src="{{ asset('assets/imagenes/vip.jpg') }}" alt="Viajes Corporativos" class="service-img">
            <h3>Traslados VIP</h3>
            <p>Pulsa para más información</p>
        </div>

        <div class="service">
            <img src="{{ asset('assets/imagenes/limusina.jpg') }}" alt="Tours Turísticos" class="service-img">
            <h3>Traslados a Eventos Especiales</h3>
            <p>Pulsa para más información</p>
        </div>
    </section>

    <section class="ventajas" id="ventajas">
        <h2>VENTAJAS DE CONTRATAR NUESTROS SERVICIOS</h2>

        <div class="ventaja">
            <img src="{{ asset('assets/imagenes/reloj.png') }}" alt="Puntualidad" class="service-img">
            <h3>Puntualidad Garantizada</h3>
            <p>Sabemos lo importante que es llegar a tiempo. Nuestros conductores siempre están preparados.</p>
        </div>

        <div class="ventaja">
            <img src="{{ asset('assets/imagenes/dinero.png') }}" alt="Precios" class="service-img">
            <h3>Precios Transparentes</h3>
            <p>Sin sorpresas con tarifas ocultas.</p>
        </div>

        <div class="ventaja">
            <img src="{{ asset('assets/imagenes/coche.png') }}" alt="Conductores" class="service-img">
            <h3>Conductores Profesionales</h3>
            <p>Conducción segura y vehículos en perfecto estado.</p>
        </div>
    </section>

    <section class="contact" id="contacto">
        <form action="#" method="post">
            <h2>Contáctanos</h2>

            <label for="nombre">Nombre:</label><br/>
            <input type="text" id="nombre" name="nombre" required><br/><br/>

            <label for="email">Email:</label><br/>
            <input type="email" id="email" name="email" required><br/><br/>

            <label for="mensaje">Mensaje:</label><br/>
            <textarea id="mensaje" name="mensaje" rows="4" required></textarea><br/><br/>

            <button type="submit">Enviar</button>
        </form>

        <p>Email: info@transfers.com</p>
        <p>Teléfono: +34 123 456 789</p>
    </section>

    <script src="{{ asset('js/script.js') }}"></script>

    @if(session()->has('nombre') && session()->has('isAdmin'))
    <script>
        alert("¡El usuario {{ session('nombre') }} se ha creado con éxito como "
            + ({{ session('isAdmin') }} === 1 ? 'Administrador' : 
                {{ session('isAdmin') }} === 2 ? 'Corporativo' : 'Viajero') + "!");
    </script>
    @php
        session()->forget('nombre');
        session()->forget('isAdmin');
    @endphp
@endif
     
</body>
</html>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Isla Transfers</title>
    <link rel="stylesheet" href="{{ asset('css/style.css') }}?v={{ time() }}">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
<body>
<<<<<<< HEAD
<h1 style="color:white"> Hola, esta es tu página para ver tus cosas que no interesan a nadie, ya que no eres administrador. CALLATE, no me INTERESA</h1>
=======
@include('header')
<h1 style="color:white; padding-top:75px;">Hola, esta es tu página para ver tus cosas que no interesan a nadie, ya que no eres administrador. CALLATE, no me INTERESA</h1>
>>>>>>> origin/bernat
</body>
</html>
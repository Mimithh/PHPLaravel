<div
  id="form-ida-vuelta"
  class="pa-form-container"
  style="display: none;"
  data-check-email-url="{{ route('admin.reservas.checkEmail') }}"
>
    <form action="{{ route('admin.reservas.store') }}" method="POST" class="pa-form">
      @csrf
      <input type="hidden" name="id_tipo_reserva" value="3">
  
      <div class="pa-dos-columnas">
        {{-- Columna “Ida” --}}
        <div class="pa-columna">
          <h3 class="pa-titulo-ida-y-vuelta">Ida</h3>
  
          {{-- Fecha de entrada --}}
          <div class="pa-form-dia-llegada">
            <label>Fecha de entrada:</label>
            <input type="date" name="fecha_entrada" class="pa-input-dia-llegada" required value="{{ old('fecha_entrada') }}">
          </div>
  
          {{-- Hora de entrada --}}
          <div class="pa-form-hora-llegada">
            <label>Hora de entrada:</label>
            <input type="time" name="hora_entrada" class="pa-input-hora-llegada" required value="{{ old('hora_entrada') }}">
          </div>
  
          {{-- Número de vuelo (ida) --}}
          <div class="pa-form-numero-vuelo">
            <label>Número de vuelo (ida):</label>
            <input type="text" name="numero_vuelo_entrada" class="pa-input-numero-vuelo" required value="{{ old('numero_vuelo_entrada') }}">
          </div>
  
          {{-- Aeropuerto de origen (ida) --}}
          <div class="pa-form-aeropuerto-origen">
            <label>Aeropuerto de origen:</label>
            <select name="origen_vuelo_entrada" class="pa-input-aeropuerto-origen aeropuerto-select" required>
              <option disabled selected>Selecciona un aeropuerto</option>
              @foreach($aeropuertos as $a)
                <option value="{{ $a->id_destino }}" {{ old('origen_vuelo_entrada') == $a->id_destino ? 'selected' : '' }}>
                  {{ $a->aeropuerto }}
                </option>
              @endforeach
            </select>
          </div>
  
          {{-- Zona --}}
          <div class="pa-form-zona">
            <label>Zona:</label>
            <select name="id_zona" class="pa-zona-select" required>
              <option disabled selected>Selecciona una zona</option>
              @foreach($zonas as $z)
                <option value="{{ $z->id_zona }}" {{ old('id_zona') == $z->id_zona ? 'selected' : '' }}>
                  {{ $z->descripcion }}
                </option>
              @endforeach
            </select>
          </div>
  
          {{-- Hotel de destino --}}
          <div class="pa-form-hotel-destino">
            <label>Hotel de destino:</label>
            <select name="id_hotel" class="pa-hotel-select" required>
              <option disabled selected>Primero selecciona zona</option>
            </select>
          </div>
  
          {{-- Número de viajeros --}}
          <div class="pa-form-numero-viajeros">
            <label>Número de viajeros:</label>
            <select name="num_viajeros" class="pa-select-numero-viajeros" required>
              <option disabled selected>Selecciona</option>
              @for($i = 1; $i <= 8; $i++)
                <option value="{{ $i }}" {{ old('num_viajeros') == $i ? 'selected' : '' }}>
                  {{ $i }} viajero{{ $i>1?'s':'' }}
                </option>
              @endfor
            </select>
          </div>
        </div>
  
        {{-- Columna “Vuelta” --}}
        <div class="pa-columna">
          <h3 class="pa-titulo-ida-y-vuelta">Vuelta</h3>
  
          {{-- Fecha de vuelo (vuelta) --}}
          <div class="pa-form-dia-vuelo">
            <label>Fecha de vuelo:</label>
            <input type="date" name="fecha_vuelo_salida" class="pa-input-dia-vuelo" required value="{{ old('fecha_vuelo_salida') }}">
          </div>
  
          {{-- Hora de vuelo (vuelta) --}}
          <div class="pa-form-hora-vuelo">
            <label>Hora de vuelo:</label>
            <input type="time" name="hora_vuelo_salida" class="pa-input-hora-vuelo" required value="{{ old('hora_vuelo_salida') }}">
          </div>
  
          {{-- Número de vuelo (vuelta) --}}
          <div class="pa-form-numero-vuelo">
            <label>Número de vuelo (vuelta):</label>
            <input type="text" name="numero_vuelo_salida" class="pa-input-numero-vuelo" required value="{{ old('numero_vuelo_salida') }}">
          </div>
  
          {{-- Hora de recogida (vuelta) --}}
          <div class="pa-form-hora-recogida">
            <label>Hora de recogida:</label>
            <input type="time" name="hora_recogida" class="pa-input-hora-recogida" required value="{{ old('hora_recogida') }}">
          </div>
  
          {{-- Aeropuerto de destino (vuelta) --}}
          <div class="pa-form-aeropuerto-origen">
            <label>Aeropuerto de destino</label>
            <select name="id_destino" class="pa-input-aeropuerto-origen aeropuerto-select" required>
              <option disabled selected>Selecciona un aeropuerto</option>
              @foreach($aeropuertos as $a)
                <option value="{{ $a->id_destino }}" {{ old('id_destino') == $a->id_destino ? 'selected' : '' }}>
                  {{ $a->aeropuerto }}
                </option>
              @endforeach
            </select>
          </div>
  
          {{-- Email del cliente --}}
          <div class="pa-form-email">
            <label>Email del cliente:</label>
            <input type="email" name="email_cliente" class="pa-input-email" required value="{{ old('email_cliente') }}">
          </div>
        </div>
      </div>

        {{-- Campos opcionales para nuevo viajero (se marcarán como required en JS) --}}
    <div class="datos-viajero-adicionales" style="display: none;">
      <div>
        <label for="nombre">Nombre:</label>
        <input
          type="text"
          id="nombre"
          name="nombre"
          class="pa-form-opcional"
          value="{{ old('nombre') }}"
        >
      </div>
      <div>
        <label for="apellido1">Apellido 1:</label>
        <input
          type="text"
          id="apellido1"
          name="apellido1"
          class="pa-form-opcional"
          value="{{ old('apellido1') }}"
        >
      </div>
      <div>
        <label for="apellido2">Apellido 2:</label>
        <input
          type="text"
          id="apellido2"
          name="apellido2"
          class="pa-form-opcional"
          value="{{ old('apellido2') }}"
        >
      </div>
      <div>
        <label for="direccion">Dirección:</label>
        <input
          type="text"
          id="direccion"
          name="direccion"
          class="pa-form-opcional"
          value="{{ old('direccion') }}"
        >
      </div>
      <div>
        <label for="codigoPostal">Código Postal:</label>
        <input
          type="text"
          id="codigoPostal"
          name="codigoPostal"
          class="pa-form-opcional"
          value="{{ old('codigoPostal') }}"
        >
      </div>
      <div>
        <label for="ciudad">Ciudad:</label>
        <input
          type="text"
          id="ciudad"
          name="ciudad"
          class="pa-form-opcional"
          value="{{ old('ciudad') }}"
        >
      </div>
      <div>
        <label for="pais">País:</label>
        <input
          type="text"
          id="pais"
          name="pais"
          class="pa-form-opcional"
          value="{{ old('pais') }}"
        >
      </div>
      <div>
        <label for="password">Contraseña:</label>
        <input
          type="password"
          id="password"
          name="password"
          class="pa-form-opcional"
        >
      </div>
    </div>
  
      {{-- Botones --}}
      <div class="pa-ida-vuelta-submit">
        <button type="button" class="pa-btn-cambiar-trayecto">Volver a selección</button>
        <button type="submit" class="pa-ida-vuelta-button">Confirmar reserva</button>
      </div>
    </form>
  </div>
  
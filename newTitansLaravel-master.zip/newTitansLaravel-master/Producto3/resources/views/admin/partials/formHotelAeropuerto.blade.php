<div
  id="form-hotel-aeropuerto"
  class="pa-form-container"
  style="display: none;"
  data-check-email-url="{{ route('admin.reservas.checkEmail') }}"
>
    <form action="{{ route('admin.reservas.store') }}" method="POST" class="pa-form">
      @csrf
      <input type="hidden" name="id_tipo_reserva" value="2">
  
      {{-- Día del vuelo --}}
      <div class="pa-form-dia-vuelo">
        <label for="fecha-vuelo">Día del vuelo:</label>
        <input
          type="date"
          id="fecha-vuelo"
          name="fecha_vuelo_salida"
          class="pa-input-dia-vuelo"
          required
          value="{{ old('fecha_vuelo_salida') }}"
        >
      </div>
  
      {{-- Hora del vuelo --}}
      <div class="pa-form-hora-vuelo">
        <label for="hora-vuelo">Hora del vuelo:</label>
        <input
          type="time"
          id="hora-vuelo"
          name="hora_vuelo_salida"
          class="pa-input-hora-vuelo"
          required
          value="{{ old('hora_vuelo_salida') }}"
        >
      </div>
  
      {{-- Número de vuelo --}}
      <div class="pa-form-numero-vuelo">
        <label for="numero-vuelo-vuelta">Número de vuelo:</label>
        <input
          type="text"
          id="numero-vuelo-vuelta"
          name="numero_vuelo_salida"
          class="pa-input-numero-vuelo"
          required
          value="{{ old('numero_vuelo_salida') }}"
        >
      </div>

      {{-- Hora de recogida (movido aquí) --}}
    <div class="pa-form-hora-recogida">
        <label for="hora-recogida">Hora de recogida:</label>
        <input
          type="time"
          id="hora-recogida"
          name="hora_recogida"
          class="pa-input-hora-recogida"
          required
          value="{{ old('hora_recogida') }}"
        >
      </div>
  
      {{-- Zona --}}
      <div class="pa-form-zona">
        <label>Zona:</label>
        <select name="id_zona" class="pa-zona-select" required>
          <option disabled selected>Selecciona una zona</option>
          @foreach($zonas as $z)
            <option value="{{ $z->id_zona }}" {{ old('id_zona') == $z->id_zona ? 'selected' : '' }}>
              {{ $z->descripcion }}
            </option>
          @endforeach
        </select>
      </div>
  
      {{-- Hotel de recogida --}}
      <div class="pa-form-hotel-destino">
        <label>Hotel de recogida:</label>
        <select name="id_hotel" class="pa-hotel-select" required>
          <option disabled selected>Primero selecciona zona</option>
        </select>
      </div>
  
      {{-- Aeropuerto de destino --}}
      <div class="pa-form-aeropuerto-origen">
        <label>Aeropuerto de destino:</label>
        <select name="id_destino" class="pa-input-aeropuerto-origen aeropuerto-select" required>
          <option disabled selected>Selecciona un aeropuerto</option>
          @foreach($aeropuertos as $aero)
            <option value="{{ $aero->id_destino }}" {{ old('id_destino') == $aero->id_destino ? 'selected' : '' }}>
              {{ $aero->aeropuerto }}
            </option>
          @endforeach
        </select>
      </div>
  
      {{-- Número de viajeros --}}
      <div class="pa-form-numero-viajeros">
        <label>Número de viajeros:</label>
        <select name="num_viajeros" class="pa-select-numero-viajeros" required>
          <option disabled selected>Selecciona</option>
          @for($i = 1; $i <= 8; $i++)
            <option value="{{ $i }}" {{ old('num_viajeros') == $i ? 'selected' : '' }}>
              {{ $i }} viajero{{ $i > 1 ? 's' : '' }}
            </option>
          @endfor
        </select>
      </div>
  
      {{-- Email del cliente --}}
      <div class="pa-form-email">
        <label for="email-cliente">Email:</label>
        <input
          type="email"
          id="email-cliente"
          name="email_cliente"
          class="pa-input-email"
          required
          value="{{ old('email_cliente') }}"
        >
      </div>

      {{-- Campos opcionales para nuevo viajero (se marcarán como required en JS) --}}
    <div class="datos-viajero-adicionales" style="display: none;">
      <div>
        <label for="nombre">Nombre:</label>
        <input
          type="text"
          id="nombre"
          name="nombre"
          class="pa-form-opcional"
          value="{{ old('nombre') }}"
        >
      </div>
      <div>
        <label for="apellido1">Apellido 1:</label>
        <input
          type="text"
          id="apellido1"
          name="apellido1"
          class="pa-form-opcional"
          value="{{ old('apellido1') }}"
        >
      </div>
      <div>
        <label for="apellido2">Apellido 2:</label>
        <input
          type="text"
          id="apellido2"
          name="apellido2"
          class="pa-form-opcional"
          value="{{ old('apellido2') }}"
        >
      </div>
      <div>
        <label for="direccion">Dirección:</label>
        <input
          type="text"
          id="direccion"
          name="direccion"
          class="pa-form-opcional"
          value="{{ old('direccion') }}"
        >
      </div>
      <div>
        <label for="codigoPostal">Código Postal:</label>
        <input
          type="text"
          id="codigoPostal"
          name="codigoPostal"
          class="pa-form-opcional"
          value="{{ old('codigoPostal') }}"
        >
      </div>
      <div>
        <label for="ciudad">Ciudad:</label>
        <input
          type="text"
          id="ciudad"
          name="ciudad"
          class="pa-form-opcional"
          value="{{ old('ciudad') }}"
        >
      </div>
      <div>
        <label for="pais">País:</label>
        <input
          type="text"
          id="pais"
          name="pais"
          class="pa-form-opcional"
          value="{{ old('pais') }}"
        >
      </div>
      <div>
        <label for="password">Contraseña:</label>
        <input
          type="password"
          id="password"
          name="password"
          class="pa-form-opcional"
        >
      </div>
    </div>
  
      {{-- Botones --}}
      <div class="pa-hotel-aeropuerto-submit">
        <button type="button" class="pa-btn-cambiar-trayecto">
          Volver a selección de trayecto
        </button>
        <button type="submit" class="pa-hotel-aeropuerto-button">
          Confirmar reserva
        </button>
      </div>
    </form>
  </div>
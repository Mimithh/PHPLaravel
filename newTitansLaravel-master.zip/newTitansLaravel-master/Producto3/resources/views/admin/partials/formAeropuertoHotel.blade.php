
<div
  id="form-aeropuerto-hotel"
  class="pa-form-container"
  style="display: none;"
  data-check-email-url="{{ route('admin.reservas.checkEmail') }}"
>
  <form action="{{ route('admin.reservas.store') }}" method="POST" class="pa-form">
    @csrf
    <input type="hidden" name="id_tipo_reserva" value="1">

    {{-- Día de llegada --}}
    <div class="pa-form-dia-llegada">
      <label for="fecha-llegada">Día de llegada:</label>
      <input
        type="date"
        id="fecha-llegada"
        name="fecha_entrada"
        class="pa-input-dia-llegada"
        required
        value="{{ old('fecha_entrada') }}"
      >
    </div>

    {{-- Hora de llegada --}}
    <div class="pa-form-hora-llegada">
      <label for="hora-llegada">Hora de llegada:</label>
      <input
        type="time"
        id="hora-llegada"
        name="hora_entrada"
        class="pa-input-hora-llegada"
        required
        value="{{ old('hora_entrada') }}"
      >
    </div>

    {{-- Número de vuelo --}}
    <div class="pa-form-numero-vuelo">
      <label for="numero-vuelo-ida">Número de vuelo:</label>
      <input
        type="text"
        id="numero-vuelo-ida"
        name="numero_vuelo_entrada"
        class="pa-input-numero-vuelo"
        required
        value="{{ old('numero_vuelo_entrada') }}"
      >
    </div>

    {{-- Aeropuerto de origen --}}
    <div class="pa-form-aeropuerto-origen">
      <label for="aeropuerto-origen">Aeropuerto de origen:</label>
      <select
        id="aeropuerto-origen"
        name="id_destino"
        class="pa-input-aeropuerto-origen aeropuerto-select"
        required
      >
        <option value="" disabled selected>Selecciona un aeropuerto</option>
        @foreach($aeropuertos as $aero)
          <option
            value="{{ $aero->id_destino }}"
            {{ old('id_destino') == $aero->id_destino ? 'selected' : '' }}
          >
            {{ $aero->aeropuerto }}
          </option>
        @endforeach
      </select>
    </div>

    {{-- Zona --}}
    <div class="pa-form-zona">
      <label for="zona">Zona:</label>
      <select
        id="zona"
        name="id_zona"
        class="pa-zona-select"
        required
      >
        <option value="" disabled selected>Selecciona una zona</option>
        @foreach($zonas as $z)
          <option
            value="{{ $z->id_zona }}"
            {{ old('id_zona') == $z->id_zona ? 'selected' : '' }}
          >
            {{ $z->descripcion }}
          </option>
        @endforeach
      </select>
    </div>

    {{-- Hotel de destino --}}
    <div class="pa-form-hotel-destino">
      <label for="hotel-destino">Hotel de destino:</label>
      <select
        id="hotel-destino"
        name="id_hotel"
        class="pa-hotel-select"
        required
      >
        <option value="" disabled selected>Primero selecciona zona</option>
        {{-- Opciones cargadas dinámicamente --}}
      </select>
    </div>

    {{-- Número de viajeros --}}
    <div class="pa-form-numero-viajeros">
      <label for="numero-viajeros">Número de viajeros:</label>
      <select
        id="numero-viajeros"
        name="num_viajeros"
        class="pa-select-numero-viajeros"
        required
      >
        <option value="" disabled selected>Selecciona</option>
        @for($i = 1; $i <= 8; $i++)
          <option
            value="{{ $i }}"
            {{ old('num_viajeros') == $i ? 'selected' : '' }}
          >
            {{ $i }} viajero{{ $i > 1 ? 's' : '' }}
          </option>
        @endfor
      </select>
    </div>

    {{-- Email del cliente --}}
    <div class="pa-form-email">
      <label for="email-cliente">Email:</label>
      <input
        type="email"
        id="email-cliente"
        name="email_cliente"
        class="pa-input-email"
        required
        value="{{ old('email_cliente') }}"
      >
    </div>

    {{-- Campos opcionales para nuevo viajero (se marcarán como required en JS) --}}
    <div class="datos-viajero-adicionales" style="display: none;">
      <div>
        <label for="nombre">Nombre:</label>
        <input
          type="text"
          id="nombre"
          name="nombre"
          class="pa-form-opcional"
          value="{{ old('nombre') }}"
        >
      </div>
      <div>
        <label for="apellido1">Apellido 1:</label>
        <input
          type="text"
          id="apellido1"
          name="apellido1"
          class="pa-form-opcional"
          value="{{ old('apellido1') }}"
        >
      </div>
      <div>
        <label for="apellido2">Apellido 2:</label>
        <input
          type="text"
          id="apellido2"
          name="apellido2"
          class="pa-form-opcional"
          value="{{ old('apellido2') }}"
        >
      </div>
      <div>
        <label for="direccion">Dirección:</label>
        <input
          type="text"
          id="direccion"
          name="direccion"
          class="pa-form-opcional"
          value="{{ old('direccion') }}"
        >
      </div>
      <div>
        <label for="codigoPostal">Código Postal:</label>
        <input
          type="text"
          id="codigoPostal"
          name="codigoPostal"
          class="pa-form-opcional"
          value="{{ old('codigoPostal') }}"
        >
      </div>
      <div>
        <label for="ciudad">Ciudad:</label>
        <input
          type="text"
          id="ciudad"
          name="ciudad"
          class="pa-form-opcional"
          value="{{ old('ciudad') }}"
        >
      </div>
      <div>
        <label for="pais">País:</label>
        <input
          type="text"
          id="pais"
          name="pais"
          class="pa-form-opcional"
          value="{{ old('pais') }}"
        >
      </div>
      <div>
        <label for="password">Contraseña:</label>
        <input
          type="password"
          id="password"
          name="password"
          class="pa-form-opcional"
        >
      </div>
    </div>

    {{-- Botones --}}
    <div class="pa-aeropuerto-hotel-submit">
      <button type="button" class="pa-btn-cambiar-trayecto">
        Volver a selección de trayecto
      </button>
      <button type="submit" class="pa-aeropuerto-hotel-button">
        Confirmar reserva
      </button>
    </div>
  </form>
</div>

<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Isla Transfers-Panel Administrador</title>
        <link rel="stylesheet" href="{{ asset('css/style.css') }}?v={{ time() }}">
        <link rel="stylesheet" href="{{ asset('css/perfilAdmin.css') }}?v={{ time() }}">
        <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
    </head>
    <body>
        <main class="pa-main">
           {{-- Mensaje de estado tras crear reserva --}}
            @if (session('status'))
              <div class="alerta-exito">
                  {{ session('status') }}
              </div>
            @endif
            @include('header')
            <h1 class="pa-h1">Perfil de Administrador</h1>
            <p class="pa-p1">Bienvenido, aquí puedes crear y gestionar reservas</p>

            <section class="pa-crear-reserva" id="options">
                <h2 class="pa-h2" id="h2-selector">
                  Crear reserva - Seleccione el trayecto que quiere reservar
                </h2>
                <h3 class="pa-h3-titulo-trayecto" id="titulo-trayecto"></h3>
          
                <div class="pa-selector-trayecto">
                  @foreach($trayectos as $t)
                    <div class="pa-trayecto-opcion"
                         data-tipo="{{ $t['tipo'] }}"
                         id="{{ $t['id'] }}">
                      <img
                        src="{{ asset('assets/imagenes/' . $t['img']) }}"
                        alt="{{ $t['alt'] }}">
                    </div>
                  @endforeach
                </div>
            </section>

            <div class="admin-calendar-link">
              <a href="{{ route('admin.calendar') }}" class="btn btn-calendar">
                📅 Ver calendario de reservas
              </a>
            </div>

             {{-- Formularios ocultos --}}

            @include('admin.partials.formAeropuertoHotel')
            @include('admin.partials.formHotelAeropuerto')
            @include('admin.partials.formIdaVuelta')

            
  


        </main>

        {{-- JS --}}

        <script src="{{ asset('js/tipoFormularios.js') }}?v={{ time() }}"></script>
        <script src="{{ asset('js/filtroHoteles.js') }}?v={{ time() }}"></script>
        <script>window.appZonas = @json($zonas);</script>
        <script>window.appVehiculos = @json($vehiculos);</script>
        <script>window.appAeropuertos = @json($aeropuertos);</script>

        
    </body>
</html>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Detalles de Reserva {{ $reserva->localizador }}</title>
  <!-- Tus CSS -->
  <link rel="stylesheet" href="{{ asset('css/style.css') }}?v={{ time() }}">
  <link rel="stylesheet" href="{{ asset('css/perfilAdmin.css') }}?v={{ time() }}">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
  <main class="pa-main">
    {{-- Incluye tu header si lo usas --}}
    @include('header')

    <h1 class="pa-h1">Detalles de Reserva {{ $reserva->localizador }}</h1>
    <div class="pa-detalle-reserva">
      <ul>
        @foreach($fields as $label => $value)
          <li>
            <strong>{{ $label }}:</strong>
            {{ $value }}
          </li>
        @endforeach
      </ul>
    
      {{-- Eliminar y volver --}}
      <form action="{{ route('admin.reservas.destroy', $reserva) }}"
            method="POST"
            onsubmit="return confirm('¿Seguro que deseas eliminar esta reserva?');"
            style="text-align:center; margin-top:1.5rem;">
        @csrf @method('DELETE')
        <button type="submit" class="btn-borrar">🗑️ Eliminar reserva</button>
      </form>
    
      <p style="text-align:center; margin-top:2em;">
        <a href="{{ route('admin.calendar') }}" class="btn btn-calendar">
          ← Volver al calendario
        </a>
      </p>
    </div>

    
  </main>
</body>
</html>

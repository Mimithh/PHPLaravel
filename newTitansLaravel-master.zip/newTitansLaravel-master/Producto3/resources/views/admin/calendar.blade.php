<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Calendario de Reservas</title>
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet">
  
  
</head>
<body>
  <h1>Calendario de Reservas</h1>
  <div id="calendar" style="max-width:900px;margin:0 auto;"></div>

  {{-- Botón para volver al panel --}}
  <p style="text-align: center; margin-bottom: 1em;">
    <a href="{{ route('admin.profile') }}" 
       style="display: inline-block; padding: .5em 1em; background: #f5b94c; color: #fff; border-radius: 4px; text-decoration: none;">
      ← Volver al Panel
    </a>
  </p>

  
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>

  <script>
    document.addEventListener('DOMContentLoaded', function() {
      const calendarEl = document.getElementById('calendar');
      const calendar   = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        locale: 'es',
        headerToolbar: {
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: {
          url: "{{ route('admin.reservas.events') }}",
          method: 'GET',
          failure() { alert('Error cargando reservas.'); }
        },
        eventTimeFormat: { hour: '2-digit', minute: '2-digit', hour12: false },  // ← COMA AQUÍ
    
        eventClick(info) {
          const id = info.event.id;
          window.location.href = "{{ url('admin/reservas') }}/" + id;
        }
      });
      calendar.render();
    });
    </script>
    

<link rel="stylesheet" href="{{ asset('css/style.css') }}?v={{ time() }}">
<link rel="stylesheet" href="{{ asset('css/perfilAdmin.css') }}?v={{ time() }}">
</body>
</html>

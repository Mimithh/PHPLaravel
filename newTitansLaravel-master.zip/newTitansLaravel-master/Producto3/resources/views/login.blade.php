<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Isla Transfers - Login</title>
    <link rel="stylesheet" href="{{ asset('css/formLogIn.css') }}?v={{ time() }}">
    <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
</head>
<body>
    @include('header')

    <div class="LogInForm">
        <h1>LOG IN</h1>
        <form method="POST" action="{{ route('login') }}">
            @csrf

            <label for="usuario">Email:</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" required autofocus>
            @error('email')
                <div class="error">{{ $message }}</div>
            @enderror

            <label for="password">Contraseña:</label>
            <input type="password" id="password" name="password" required>
            @error('password')
                <div class="error">{{ $message }}</div>
            @enderror

           <!-- <label for="type">Tipo de usuario:</label>
            <select id="type" name="type" required>
                <option value="viajero" {{ old('type')=='viajero' ? 'selected' : '' }}>Viajero</option>
                <option value="corporativo" {{ old('type')=='corporativo' ? 'selected' : '' }}>Corporativo</option>
                <option value="administrador" {{ old('type')=='administrador' ? 'selected' : '' }}>Administrador</option>
            </select>-->
            @error('type')
                <div class="error">{{ $message }}</div>
            @enderror

            <div class="botones">
                <button type="submit" id="btnLogIn">ENTRAR</button>
                <a href="{{ url('/registro') }}" id="btnRegistrarse">REGISTRARSE</a>
            </div>
        </form>

        @if($errors->any() && !session('status'))
            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    alert('Credenciales inválidas.');
                });
            </script>
        @endif

        @if(session('status') === 'registrado')
            @php
                $tipoUsuario = session('isAdmin') == 1 ? 'Administrador' : (session('isAdmin') == 2 ? 'Corporativo' : 'Usuario');
            @endphp
            <script>
                window.addEventListener('DOMContentLoaded', () => {
                    alert(`¡${{ session('nombre') }}, ${tipoUsuario} ha sido registrado con éxito!`);
                });
            </script>
        @endif
    </div>
</body>
</html>
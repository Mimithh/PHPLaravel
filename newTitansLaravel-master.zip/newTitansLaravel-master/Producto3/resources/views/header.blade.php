{{-- resources/views/partials/header.blade.php --}}

<header>
    <div class="titleLogo">
        <a href="{{ url('/') }}">
            <img src="{{ asset('assets/imagenes/newTitans.svg') }}"
                 class="service-img"
                 alt="Logo Isla Transfers">
        </a>
        <a href="{{ url('/') }}">
            <h1>Isla Transfers</h1>
        </a>
    </div>

    <nav>


        @if (session('userName'))
            @php
                $userName = session('userName');
                $isAdmin  = session('isAdmin');
            @endphp

            {{-- Saludo y enlace al perfil correspondiente --}}
            <a href="{{ $isAdmin == 1
                         ? route('admin.profile')
                         : ($isAdmin == 2
                             ? route('login')
                             : route('login')) }}">
                Hola, {{ strtoupper($userName) }}
            </a>

            {{-- Etiqueta de rol --}}
            @if ($isAdmin == 1)
                <span class="admin-label">[ Admin ]</span>
            @elseif ($isAdmin == 2)
                <span class="admin-label">[ Corp ]</span>
            @endif

            {{-- Enlace para registrar nuevo usuario (solo admins) --}}
            @if ($isAdmin == 1)
                <a href="{{ route('registro') }}" class="addUser">
                    <!-- Puedes usar un icono dentro si lo deseas -->
                    <i class="fa fa-user-plus"></i> Nuevo usuario
                </a>
            @endif

            {{-- Logout --}}
            <a href="#"
               onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                CERRAR SESIÓN
            </a>
            <form id="logout-form"
                  action="{{ route('logout') }}"
                  method="POST"
                  style="display: none;">
                @csrf
            </form>
        @else
            <a href="{{ route('login') }}">LOGIN</a>
            <a href="{{ route('registro') }}">REGISTRARSE</a>
        @endif
    </nav>
</header>

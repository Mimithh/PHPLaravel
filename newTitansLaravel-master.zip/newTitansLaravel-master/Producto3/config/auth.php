<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Defaults
    |--------------------------------------------------------------------------
    |
    | Define el guard por defecto y el broker de passwords.
    |
    */

    'defaults' => [
        'guard'     => env('AUTH_GUARD', 'web'),
        'passwords' => env('AUTH_PASSWORD_BROKER', 'users'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Authentication Guards
    |--------------------------------------------------------------------------
    |
    | Cada guard usa un driver y un provider distinto.
    |
    */

    'guards' => [
        'web' => [
            'driver'   => 'session',
            'provider' => 'users',
        ],

        'administrador' => [
            'driver'   => 'session',
            'provider' => 'administradores',
        ],

        'corporativo' => [
            'driver'   => 'session',
            'provider' => 'corporativos',
        ],

        'viajero' => [
            'driver'   => 'session',
            'provider' => 'viajeros',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | User Providers
    |--------------------------------------------------------------------------
    |
    | Define los modelos que representan cada tabla.
    |
    */

    'providers' => [
        'users' => [
            'driver' => 'eloquent',
            'model'  => App\Models\User::class,
        ],

        'administradores' => [
            'driver' => 'eloquent',
            'model'  => App\Models\AdministradorModel::class,
        ],

        'corporativos' => [
            'driver' => 'eloquent',
            'model'  => App\Models\CorporativoModel::class,
        ],

        'viajeros' => [
            'driver' => 'eloquent',
            'model'  => App\Models\UsuarioModel::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Resetting Passwords
    |--------------------------------------------------------------------------
    |
    */

    'passwords' => [
        'users' => [
            'provider' => 'users',
            'table'    => 'password_reset_tokens',
            'expire'   => 60,
            'throttle' => 60,
        ],
        // puedes añadir brokers para otros perfiles si lo necesitas
    ],

    /*
    |--------------------------------------------------------------------------
    | Password Confirmation Timeout
    |--------------------------------------------------------------------------
    |
    */

    'password_timeout' => env('AUTH_PASSWORD_TIMEOUT', 10800),

];